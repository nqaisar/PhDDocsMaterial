﻿// Copyright (c) Microsoft Open Technologies, Inc. All rights reserved. See License.md in the project root for license information.

using System.Reflection;

[assembly: AssemblyTitle("Microsoft.AspNet.SignalR.Client.WinRT")]
[assembly: AssemblyDescription("Windows RT client for SignalR")]
