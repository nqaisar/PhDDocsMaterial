<?php
/*
 * @category Lib
 * @package Test Suit
 * @copyright 2011, 2012 Dmitry Sheiko (http://dsheiko.com)
 * @license GNU
 */

return array(
    "adapter" => "mysqli",
    "host" => "localhost",
    "username" => "root",
    "password" => "",
    "dbname" => "test",
);