using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WTcpClient
{
	/// <summary>
	/// Summary description for ConnectDlg.
	/// </summary>
	public class ConnectDlg : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button OkBtn;
		private System.Windows.Forms.Button CancelBtn;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox UName;
		private System.Windows.Forms.TextBox PWord;
		/// <summary>
		/// Required designer variable.
		/// </summary>

		private string username;
		private string password;
		private string ipAdd;
		private string port;
		private MaskedTextBox.MaskedTextBox IPAdd;
		private MaskedTextBox.MaskedTextBox Port;
		
		public string UserName
		{
			get { return username; }
			set 
			{
				username = value;
				UName.Text = username;
			}
		}
		
		public string PassWord
		{
			get { return password; }
			set 
			{
				password = value;
				PWord.Text = password;
			}
		}
		public string PortNum
		{
			get { return port; }
			set 
			{
				port = value;
				Port.Text = port;
			}
		}
		
		public string IpAdd
		{
			get { return ipAdd; }
			set 
			{
				ipAdd = value;
				IPAdd.Text = ipAdd;
			}
		}
		private System.ComponentModel.Container components = null;

		public ConnectDlg()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.PWord = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.CancelBtn = new System.Windows.Forms.Button();
			this.OkBtn = new System.Windows.Forms.Button();
			this.UName = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.IPAdd = new MaskedTextBox.MaskedTextBox();
			this.Port = new MaskedTextBox.MaskedTextBox();
			this.SuspendLayout();
			// 
			// PWord
			// 
			this.PWord.Location = new System.Drawing.Point(120, 112);
			this.PWord.Name = "PWord";
			this.PWord.PasswordChar = '*';
			this.PWord.Size = new System.Drawing.Size(104, 20);
			this.PWord.TabIndex = 5;
			this.PWord.Text = "user1";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(40, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(72, 16);
			this.label1.TabIndex = 2;
			this.label1.Text = "IP Address";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(40, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(64, 24);
			this.label2.TabIndex = 4;
			this.label2.Text = "Port";
			// 
			// CancelBtn
			// 
			this.CancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.CancelBtn.Location = new System.Drawing.Point(184, 144);
			this.CancelBtn.Name = "CancelBtn";
			this.CancelBtn.TabIndex = 6;
			this.CancelBtn.Text = "Cancel";
			this.CancelBtn.Click += new System.EventHandler(this.OnCancel);
			// 
			// OkBtn
			// 
			this.OkBtn.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.OkBtn.Location = new System.Drawing.Point(48, 144);
			this.OkBtn.Name = "OkBtn";
			this.OkBtn.TabIndex = 7;
			this.OkBtn.Text = "Ok";
			this.OkBtn.Click += new System.EventHandler(this.OnOk);
			// 
			// UName
			// 
			this.UName.Location = new System.Drawing.Point(120, 80);
			this.UName.Name = "UName";
			this.UName.Size = new System.Drawing.Size(104, 20);
			this.UName.TabIndex = 3;
			this.UName.Text = "user1";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(40, 112);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(64, 24);
			this.label4.TabIndex = 4;
			this.label4.Text = "Password";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(40, 80);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(72, 16);
			this.label3.TabIndex = 2;
			this.label3.Text = "User Name";
			// 
			// IPAdd
			// 
			this.IPAdd.DateOnly = false;
			this.IPAdd.DecimalOnly = false;
			this.IPAdd.DigitOnly = false;
			this.IPAdd.IPAddrOnly = false;
			this.IPAdd.Location = new System.Drawing.Point(120, 16);
			this.IPAdd.Name = "IPAdd";
			this.IPAdd.PhoneWithAreaCode = false;
			this.IPAdd.Size = new System.Drawing.Size(104, 20);
			this.IPAdd.SSNOnly = false;
			this.IPAdd.TabIndex = 10;
			this.IPAdd.Text = "169.254.213.10";
			// 
			// Port
			// 
			this.Port.DateOnly = false;
			this.Port.DecimalOnly = false;
			this.Port.DigitOnly = false;
			this.Port.IPAddrOnly = false;
			this.Port.Location = new System.Drawing.Point(120, 48);
			this.Port.Name = "Port";
			this.Port.PhoneWithAreaCode = false;
			this.Port.Size = new System.Drawing.Size(104, 20);
			this.Port.SSNOnly = false;
			this.Port.TabIndex = 11;
			this.Port.Text = "8002";
			// 
			// ConnectDlg
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 181);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Port,
																		  this.IPAdd,
																		  this.label3,
																		  this.label4,
																		  this.UName,
																		  this.PWord,
																		  this.label2,
																		  this.label1,
																		  this.CancelBtn,
																		  this.OkBtn});
			this.Name = "ConnectDlg";
			this.Text = "ConnectDlg";
			this.ResumeLayout(false);

		}
		#endregion
		protected void OnCancel(Object mySender , EventArgs myArgs)
		{
			this.Close();			
		}
		protected void OnOk(Object mySender , EventArgs myArgs)
		{
			UserName = UName.Text;
			PassWord = PWord.Text;
			ipAdd = IPAdd.Text;
			port = Port.Text;
		}
	}

}
