using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Globalization;

using System.IO;
using System.Xml;

namespace WTcpSrv
{
	public struct Issue
	{
		public string symbol;
		public string bid;
		public string offer;
		public string volume;
	}
	public enum FileType 
	{
		TextFile = 0,
		XMLFile = 1,
		URISrc = 2
	}

	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem MenuExit;

		private Issue isu = new Issue();
		private FileType fileType;

		private int MaxConnected=400;
		private int HighLightDelay = 300;

		private Encoding ASCII = Encoding.ASCII;
		private static long connectId=0;
		private static AutoResetEvent JobDone = new AutoResetEvent(false);

		private TcpListener tcpLsn;
		private Hashtable socketHolder = new Hashtable();
		private Hashtable threadHolder = new Hashtable();
		private Hashtable userHolder = new Hashtable();
		bool keepUser;

		private Thread  fThd;

		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.MenuItem MenuStartThread;
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.ColumnHeader Phone;
		private System.Windows.Forms.ColumnHeader UserName;
		private System.Windows.Forms.ColumnHeader EmpName;
		private System.Windows.Forms.ColumnHeader PhoneNum;
		private System.Windows.Forms.MenuItem menuClean;
		private System.Windows.Forms.ListView listView2;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private System.Windows.Forms.ImageList imageList1;
		private System.Windows.Forms.StatusBar stBar;
		private System.Windows.Forms.MenuItem LoadData;
		private System.Windows.Forms.MenuItem menuStop;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuTextFile;
		private System.Windows.Forms.StatusBarPanel stpanel;
 
		public Form1()
		{
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			tcpLsn = new TcpListener(8002);			
			tcpLsn.Start();
			stpanel.Text = "Listen at: " + tcpLsn.LocalEndpoint.ToString();
			Thread tcpThd = new Thread(new ThreadStart(WaitingForClient));
			threadHolder.Add(connectId, tcpThd);
			tcpThd.Start() ;

			this.Paint += new PaintEventHandler(Form1_Paint);
		}
		private void Form1_Paint(object sender, PaintEventArgs e)
		{
			Graphics g = e.Graphics;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );

		}

		#region Windows Form Designer generated code

		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.MenuStartThread = new System.Windows.Forms.MenuItem();
			this.menuStop = new System.Windows.Forms.MenuItem();
			this.stBar = new System.Windows.Forms.StatusBar();
			this.stpanel = new System.Windows.Forms.StatusBarPanel();
			this.LoadData = new System.Windows.Forms.MenuItem();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.MenuExit = new System.Windows.Forms.MenuItem();
			this.Phone = new System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.PhoneNum = new System.Windows.Forms.ColumnHeader();
			this.menuClean = new System.Windows.Forms.MenuItem();
			this.EmpName = new System.Windows.Forms.ColumnHeader();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.listView1 = new System.Windows.Forms.ListView();
			this.UserName = new System.Windows.Forms.ColumnHeader();
			this.listView2 = new System.Windows.Forms.ListView();
			this.imageList1 = new System.Windows.Forms.ImageList(this.components);
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuTextFile = new System.Windows.Forms.MenuItem();
			((System.ComponentModel.ISupportInitialize)(this.stpanel)).BeginInit();
			this.SuspendLayout();
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 1;
			this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.MenuStartThread,
																					  this.menuStop});
			this.menuItem3.Text = "Server";
			// 
			// MenuStartThread
			// 
			this.MenuStartThread.Checked = true;
			this.MenuStartThread.Index = 0;
			this.MenuStartThread.Text = "Start";
			this.MenuStartThread.Click += new System.EventHandler(this.OnMenuStart);
			// 
			// menuStop
			// 
			this.menuStop.Index = 1;
			this.menuStop.Text = "Stop";
			this.menuStop.Click += new System.EventHandler(this.OnMemuStop);
			// 
			// stBar
			// 
			this.stBar.Location = new System.Drawing.Point(0, 357);
			this.stBar.Name = "stBar";
			this.stBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																					 this.stpanel});
			this.stBar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.stBar.ShowPanels = true;
			this.stBar.Size = new System.Drawing.Size(320, 20);
			this.stBar.TabIndex = 3;
			// 
			// stpanel
			// 
			this.stpanel.Alignment = System.Windows.Forms.HorizontalAlignment.Right;
			this.stpanel.Width = 200;
			// 
			// LoadData
			// 
			this.LoadData.Index = 2;
			this.LoadData.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuItem2,
																					 this.menuTextFile});
			this.LoadData.Text = "Load Data";
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Status";
			this.columnHeader1.Width = 57;
			// 
			// MenuExit
			// 
			this.MenuExit.Index = 1;
			this.MenuExit.Text = "Exit";
			this.MenuExit.Click += new System.EventHandler(this.OnMenuExit);
			// 
			// Phone
			// 
			this.Phone.Text = "Bid";
			this.Phone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// columnHeader3
			// 
			this.columnHeader3.Text = "Login Time";
			this.columnHeader3.Width = 141;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "User Name";
			this.columnHeader2.Width = 86;
			// 
			// PhoneNum
			// 
			this.PhoneNum.Text = "Volume";
			this.PhoneNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.PhoneNum.Width = 92;
			// 
			// menuClean
			// 
			this.menuClean.Index = 0;
			this.menuClean.Text = "Clean";
			this.menuClean.Click += new System.EventHandler(this.OnMenuClean);
			// 
			// EmpName
			// 
			this.EmpName.Text = "Offer";
			this.EmpName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.EmpName.Width = 72;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItem3,
																					  this.LoadData});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuClean,
																					  this.MenuExit});
			this.menuItem1.Text = "File";
			// 
			// listView1
			// 
			this.listView1.AccessibleDescription = "";
			this.listView1.AccessibleName = "";
			this.listView1.BackColor = System.Drawing.Color.Black;
			this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.UserName,
																						this.Phone,
																						this.EmpName,
																						this.PhoneNum});
			this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.listView1.ForeColor = System.Drawing.SystemColors.Info;
			this.listView1.HideSelection = false;
			this.listView1.HoverSelection = true;
			this.listView1.Location = new System.Drawing.Point(16, 120);
			this.listView1.Name = "listView1";
			this.listView1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.listView1.Size = new System.Drawing.Size(288, 232);
			this.listView1.TabIndex = 1;
			this.listView1.View = System.Windows.Forms.View.Details;
			// 
			// UserName
			// 
			this.UserName.Text = "Symbol";
			// 
			// listView2
			// 
			this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.columnHeader1,
																						this.columnHeader2,
																						this.columnHeader3});
			this.listView2.Location = new System.Drawing.Point(16, 8);
			this.listView2.Name = "listView2";
			this.listView2.Size = new System.Drawing.Size(288, 96);
			this.listView2.SmallImageList = this.imageList1;
			this.listView2.StateImageList = this.imageList1;
			this.listView2.TabIndex = 2;
			this.listView2.View = System.Windows.Forms.View.Details;
			// 
			// imageList1
			// 
			this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
			this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
			this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 0;
			this.menuItem2.Text = "XML File";
			this.menuItem2.Click += new System.EventHandler(this.menuXMLFile_Click);
			// 
			// menuTextFile
			// 
			this.menuTextFile.Index = 1;
			this.menuTextFile.Text = "Text File";
			this.menuTextFile.Click += new System.EventHandler(this.menuTextFile_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(320, 377);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.stBar,
																		  this.listView2,
																		  this.listView1});
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Tcp Server";
			((System.ComponentModel.ISupportInitialize)(this.stpanel)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		public void WaitingForClient()
		{
			while(true)
			{
				// Accept will block until someone connects
				Socket sckt = tcpLsn.AcceptSocket();
				if (connectId < 10000)
					Interlocked.Increment(ref connectId);
				else
					connectId = 1;
				if (socketHolder.Count < MaxConnected )
				{
					while (socketHolder.Contains(connectId) )
					{
						Interlocked.Increment(ref connectId);
					}
	
					Thread td = new Thread(new ThreadStart(ReadSocket));
					lock(this)
					{
						// it is used to keep connected Sockets
						socketHolder.Add(connectId, sckt);
						// it is used to keep the active thread
						threadHolder.Add(connectId, td);
					}
					td.Start();
				}
			}
		}
		public void ReadSocket()
		{
			// realId will be not changed for each thread, 
			// but connectId is changed. it can't be used to delete object from Hashtable
			long realId = connectId;
			int ind=-1;
			Socket s = (Socket)socketHolder[realId];
			while (true) 
			{
				if(s.Connected)
				{
					Byte[] receive = new Byte[37] ;
					try
					{
						// Receive will block until data coming
						// ret is 0 or Exception happen when Socket connection is broken
						int ret=s.Receive(receive,receive.Length,0);
						if (ret>0)
						{
							string tmp = null;
							tmp = System.Text.Encoding.ASCII.GetString(receive);
							if(tmp.Length > 0)
							{
								DateTime now1=DateTime.Now;;
								String strDate;
								strDate = now1.ToShortDateString() + " " 
												+ now1.ToLongTimeString();
								
								ListViewItem newItem = new ListViewItem();

								string[] strArry=tmp.Split(':');
								int code = checkUserInfo(strArry[0]);
								if(code==2)
								{
									userHolder.Add(realId, strArry[0]);
									newItem.SubItems.Add(strArry[0]);
									newItem.ImageIndex = 0;
									newItem.SubItems.Add(strDate);
									this.listView2.Items.Add(newItem);
									ind=this.listView2.Items.IndexOf(newItem);
								}
								else if( code==1)
								{
									string connFail = String.Format(":The user {0} is connected already", strArry[0]);
									Byte[] byteData = ASCII.GetBytes(connFail.ToCharArray());
									s.Send(byteData, byteData.Length, 0);
									s.Close();
									break;
								}
								else if(code==0)
								{
									string connFail = String.Format(":The user {0} is invalidate", strArry[0]);
									Byte[] byteData = ASCII.GetBytes(connFail.ToCharArray());
									s.Send(byteData, byteData.Length, 0);
									s.Close();
									break;
								}
							}
						}
						else
						{
							this.listView2.Items[ind].ImageIndex=1;
							keepUser=false;
							break;
						}
					}
					catch (Exception e) 
					{
						if( !s.Connected )
						{
							this.listView2.Items[ind].ImageIndex=1;
							keepUser=false;
							break;
						}
					}
				}
			}
			CloseTheThread(realId);
		}

		private int checkUserInfo(string userId)
		{
			//  check the userId and password first
			// ....

			if (true)// suppose it ok
			{
				if (userHolder.ContainsValue(userId))
				{
					keepUser=true;
					return 1; // user is login already
				}
			}
			else
				return 0; // user not in the database
			return 2; // user is vailidate
		}
		private void CloseTheThread(long realId)
		{
			if(!keepUser) userHolder.Remove(realId);
			Thread thd = (Thread)threadHolder[realId];
			lock(this)
			{
				socketHolder.Remove(realId);
				threadHolder.Remove(realId);
			}
			thd.Abort();
		}
		private void menuTextFile_Click(object sender, System.EventArgs e)
		{
			fThd = new Thread(new ThreadStart(LoadThread));
			fileType = FileType.TextFile;
			fThd.Start() ;
		}
		private void menuXMLFile_Click(object sender, System.EventArgs e)
		{
			fThd = new Thread(new ThreadStart(LoadXmlThread));
			fileType = FileType.XMLFile;
			fThd.Start() ;
		}
		public void LoadThread()
		{
			MethodInvoker miv = new MethodInvoker(this.UpdateListView);
			string tmp = null;
			string xmlString = null;
			switch (fileType) 
			{
			case FileType.TextFile :
				string sendMsg=null;
				StreamReader sr = File.OpenText("Issue.txt");
				while((tmp = sr.ReadLine()) !=null )
				{
					if (tmp =="")
						break;

					isu.symbol= Mid(tmp, 0, 4).TrimEnd(' ');
					isu.bid = Mid(tmp, 4, 5).TrimEnd(' ');
					isu.offer = Mid(tmp, 9, 5).TrimEnd(' ');
					isu.volume = Mid(tmp, 16, tmp.Length-16).TrimEnd(' ');

					sendMsg = "\v" + tmp + "\n"; // add send message's head and end char
					SendDataToAllClient(sendMsg);

					this.BeginInvoke(miv);
					JobDone.WaitOne();
				}
				sr.Close();
				break;
			}

			fThd.Abort();
		}
		public void LoadXmlThread()
		{
			MethodInvoker miv = new MethodInvoker(this.UpdateListView);
			string tmp = null;
			string xmlString = null;

			int recordFlg = -1;
			int textCount =0;
			xmlString = "\v"+"<?xml version='1.0'?>";

			XmlTextReader tr = new XmlTextReader("issue.xml");
			while(tr.Read())
			{
				switch (tr.NodeType)
				{
					case XmlNodeType.Element:
						if (tr.Name == "Issue")
						{
							recordFlg++;
							if(recordFlg > 0)
							{
								textCount=0;
								xmlString += CreateXmlElement(tr.Name, 2);
								xmlString += "\n";
								SendDataToAllClient(xmlString);
								xmlString = "\v"+"<?xml version='1.0'?>";
							
								this.BeginInvoke(miv);
								JobDone.WaitOne();
							}
						}
						if (recordFlg >= 0)
						{
							xmlString += CreateXmlElement(tr.Name, 1);
							tmp = tr.Name;
						}

						break;
					case XmlNodeType.Text:
					switch(++textCount) 
					{
						case 1:
							isu.symbol=tr.Value;
							break;
						case 2:
							isu.bid=tr.Value;
							break;
						case 3:
							isu.offer=tr.Value;
							break;
						case 4:
							isu.volume=tr.Value;
							break;
					}
						xmlString += tr.Value;
						xmlString += CreateXmlElement(tmp, 2);
						break;
				}
			}
			fThd.Abort();
		}
		string CreateXmlElement(string elem, int ord)
		{
			string tmp = null;
			if (ord == 1)
				tmp = String.Format("<{0}>", elem);
			else
				tmp = String.Format("</{0}>", elem);
				
			return tmp;
		}
		private void SendDataToAllClient(string str)
		{
			foreach (Socket s in socketHolder.Values) 
			{
				if(s.Connected)
				{
					Byte[] byteData = ASCII.GetBytes(str.ToCharArray());
					s.Send(byteData, byteData.Length, 0);
				}
			}
		}
		private void UpdateListView() 
		{
			int ind=-1;
			for (int i=0; i<this.listView1.Items.Count;i++)
			{
				if (this.listView1.Items[i].Text == isu.symbol.ToString())
				{
					ind=i;
					break;
				}
			}
			if (ind == -1)
			{
				ListViewItem newItem = new ListViewItem(isu.symbol.ToString());						
				newItem.SubItems.Add(isu.bid);
				newItem.SubItems.Add(isu.offer);
				newItem.SubItems.Add(isu.volume);
				
				this.listView1.Items.Add(newItem);	
				int i=this.listView1.Items.IndexOf(newItem);
				setColColorHL(i, 0, System.Drawing.Color.FromArgb(255, 99, 99) );
				setColColorHL(i, 1, System.Drawing.Color.FromArgb(255, 99, 99) );
				this.listView1.Update();
				Thread.Sleep(HighLightDelay);
				setColColor(i, 0, System.Drawing.Color.FromArgb(0, 255, 128) );
				setColColor(i, 1, System.Drawing.Color.FromArgb(255, 255, 128) );
			}
			else
			{
				this.listView1.Items[ind].Text = isu.symbol.ToString();
				this.listView1.Items[ind].SubItems[1].Text = (isu.bid);
				this.listView1.Items[ind].SubItems[2].Text = (isu.offer);
				this.listView1.Items[ind].SubItems[3].Text = (isu.volume);
				setColColorHL(ind, 0, System.Drawing.Color.FromArgb(255, 99, 99) );
				setColColorHL(ind, 1, System.Drawing.Color.FromArgb(255, 99, 99) );
				this.listView1.Update();
				Thread.Sleep(HighLightDelay);
				setColColor(ind, 0, System.Drawing.Color.FromArgb(0, 255, 128) );
				setColColor(ind, 1, System.Drawing.Color.FromArgb(255, 255, 128) );
			}
			JobDone.Set();
		}

		private void setRowColor(int rowNum, Color colr )
		{
			for (int i=0; i<this.listView1.Items[rowNum].SubItems.Count;i++)
				if (rowNum%2 ==0)
					this.listView1.Items[rowNum].SubItems[i].BackColor = colr;
		}
		private void setColColor(int rowNum, int colNum, Color colr )
		{
			this.listView1.Items[rowNum].SubItems[colNum].ForeColor = colr;
		}
		private void setColColorHL(int rowNum, int colNum, Color colr )
		{
			this.listView1.Items[rowNum].SubItems[colNum].ForeColor = colr;
		}
		private void OnMenuClean(object sender, System.EventArgs e)
		{
			this.listView1.Items.Clear();
		}

		public string Mid(String strParam, int startIndex, int length)
		{
			string tmpstr = strParam.Substring(startIndex, length);
			return tmpstr;
		}

		private void OnMenuExit(object sender, System.EventArgs e)
		{
			if(fThd.IsAlive)
				fThd.Abort();
			if (tcpLsn!=null)
				tcpLsn.Stop();
			foreach (Socket s in socketHolder.Values) 
			{
				if(s.Connected)
					s.Close();
			}
			foreach (Thread t in threadHolder.Values) 
			{
				if(t.IsAlive)
					t.Abort();
			}
			Application.Exit();
		}

		private void OnMenuStart(object sender, System.EventArgs e)
		{
			if (tcpLsn==null)
			{
				tcpLsn= new TcpListener(8002);
				tcpLsn.Start();
				Thread tcpThd = new Thread(new ThreadStart(WaitingForClient));
				threadHolder.Add(connectId, tcpThd);
				tcpThd.Start() ;
				stpanel.Text = "Listen at: " + tcpLsn.LocalEndpoint.ToString();
				menuStop.Checked=false;
				MenuStartThread.Checked=true;
			}
		}
		private void OnMemuStop(object sender, System.EventArgs e)
		{
			tcpLsn.Stop();
			tcpLsn=null;

			Thread tcpThd = (Thread)threadHolder[0];
			tcpThd.Abort() ;
			threadHolder.Remove(0);
			stpanel.Text="Start Server Please!";
			foreach (Socket s in socketHolder.Values) 
			{
				if(s.Connected)
				   s.Close();
			}
			foreach (Thread t in threadHolder.Values) 
			{
				if(t.IsAlive)
					t.Abort();
			}
			menuStop.Checked=true;
			MenuStartThread.Checked=false;
		}
	}
}
